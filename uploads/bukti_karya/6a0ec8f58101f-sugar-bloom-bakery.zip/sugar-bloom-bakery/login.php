<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - sugarbloom.</title>

    <link rel="stylesheet" href="css/login.css">

   <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />

</head>
<body>

<div class="login-container">

    <form action="proses_login.php" method="POST" class="login-form">

        <h1>sugar<span>bloom.</span></h1>
        <p>Masuk dan pilih dessert favoritmu ✨</p>

        <div class="input-box">
            <input type="text" name="username" placeholder="Username" required>
        </div>

        <div class="input-box">
            <input type="password" name="password" placeholder="Password" required>
        </div>

        <button type="submit">Login</button>

        <div class="register-link">
            Belum punya akun?
            <a href="register.php">Register</a>
        </div>

    </form>

</div>
