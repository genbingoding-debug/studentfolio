<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - sugarbloom.</title>

    <link rel="stylesheet" href="css/register.css">

   <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />

</head>
<body>

<div class="register-container">

    <form action="proses_register.php" method="POST" enctype="multipart/form-data" class="register-form">

        <h1>sugar<span>bloom.</span></h1>
        <p>Create Your Account ✨</p>

        <div class="input-box">
            <input type="text" name="nama" placeholder="Nama Lengkap" required>
        </div>

        <div class="input-box">
            <input type="text" name="username" placeholder="Username" required>
        </div>

        <div class="input-box">
            <input type="password" name="password" placeholder="Password" required>
        </div>

        <div class="input-box">
            <input type="file" name="foto" required>
        </div>

        <button type="submit">Register</button>

        <div class="login-link">
            Sudah punya akun?
            <a href="login.php">Login</a>
        </div>

    </form>

</div>

</body>
</html>