<?php

$conn = mysqli_connect("localhost", "root", "", "sugar_bloom");

if(!$conn){
    die("Koneksi gagal");
}

?>