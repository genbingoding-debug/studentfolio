
<?php
session_start();
?>
<div class="navbar-extra>
    <?php if(isset($_SESSION['nama'])) : ?>
        <span class="user-login">
            Halo, <?= $_SESSION['nama'] ?>
        </span>
    <?php endif; ?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sugar Bloom Bakery</title>

    <!--fonts-->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />

    <!--feather icons-->
    <script src="https://unpkg.com/feather-icons"></script>

    <!--my style-->
    <link rel="stylesheet" href="css/style.css" />
</head>

<body>
    <!--navbar start-->
    <nav class="navbar">
        <a href="#" class="navbar-logo">sugar<span>bloom</span>.</a>

        <div class="navbar-nav">
            <a href="#home">Home</a>
            <a href="#about">Tentang Kami</a>
            <a href="#menu">Menu</a>
            <a href="#contact">Kontak</a>
        </div>

        <div class="navbar-extra">
            <a href="#" id="search"><i data-feather="search"></i></a>
            <a href="#" id="shopping-cart"><i data-feather="shopping-cart"></i></a>
            <a href="#" id="menu-toggle"><i data-feather="menu"></i></a>
        </div>
    </nav>
    <!--navbar end-->

    <!--hero section start-->
    <section class="hero" id="home">
        <main class="content">
            <h1>A Bloom of <span>Sweetness</span></h1>
            <p>
                Sugar Bloom lahir dari hal-hal kecil yang manis. Dipanggang dengan penuh perhatian, setiap sajian menghadirkan kelembutan yang bikin hari terasa lebih cerah. Karena manis yang sederhana selalu punya caranya sendiri untuk mekar.
            </p>
            <p>
                <a href="#" class="cta">Beli Sekarang</a>
            </p>
        </main>
    </section>

    <!--hero section end-->

    <section class="about" id="about">
        <h2><span>Tentang </span>Kami</h2>

        <div class="row">
            <div class="about-img">
                <img src="img/tentang-kami.jpg" alt="Tentang Kami" />
            </div>

            <div class="content">
                <h3>Kenapa memilih Sugar Bloom?</h3>

                <p>
                    Sugar Bloom hadir untuk kamu yang menyukai manis yang sederhana dan berkelas. Setiap produk dibuat dengan perhatian pada detail, menghasilkan rasa lembut dan seimbang di setiap gigitan.
                </p>
                <p></p>
                <p>
                    Setiap sajian Sugar Bloom dipanggang dengan penuh perhatian untuk menjaga kelembutan rasa dan kualitas di setiap detailnya. Dari aroma hangat hingga tekstur yang ringan, kami ingin menghadirkan manis yang terasa pas.
                </p>
            </div>
        </div>
    </section>

    <!--about section end-->

    <!--menu section start-->
    <section class="menu" id="menu">
        <h2><span>Menu </span>Kami</h2>
        <p>Rangkaian menu unggulan dengan kualitas terbaik dan rasa yang telah menjadi favorit banyak pelanggan.</p>

        <div class="row">
            <div class="menu-card">
                <img src="img/menu/croissant 1.png" alt="Croissant" class="menu-card-img" />
                <h3 class="menu-card-title">- Croissant -</h3>
                <p class="menu-card-price">IDR 15K</p>
            </div>
            <div class="menu-card">
                <img src="img/menu/donut 1.png" alt="Croissant" class="menu-card-img" />
                <h3 class="menu-card-title">- Choco Donut-</h3>
                <p class="menu-card-price">IDR 10K</p>
            </div>
            <div class="menu-card">
                <img src="img/menu/shortcake 1.png" alt="Croissant" class="menu-card-img" />
                <h3 class="menu-card-title">- Strawberry Shortcake-</h3>
                <p class="menu-card-price">IDR 20K</p>
            </div>
            <div class="menu-card">
                <img src="img/menu/rolls 1.png" alt="Cinamon" class="menu-card-img" />
                <h3 class="menu-card-title">- Cinamon Rolls -</h3>
                <p class="menu-card-price">IDR 22K</p>
            </div>
        </div>
    </section>

    <!--menu section end-->

    <!--contact section start-->
    <section id="contact" class="contact">
        <h2><span>Kontak </span>Kami</h2>
        <p>Hubungi kami untuk pemesanan, pertanyaan, atau informasi lebih lanjut. Kami siap membantu kebutuhan mamismu</p>
        <div class="row">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63453.76656496099!2d107.24934663386533!3d-6.282074670445798!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69780f4b22834f%3A0x3f21d3f70aaef632!2sKarawang%20Barat%2C%20Kec.%20Karawang%20Bar.%2C%20Karawang%2C%20Jawa%20Barat!5e0!3m2!1sid!2sid!4v1770351226841!5m2!1sid!2sid"
                allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="map"></iframe>
            <form action="">
                <div class="input-group">
                    <i data-feather="user"></i>
                    <input type="text" placeholder="Nama">
                </div>
                <div class="input-group">
                    <i data-feather="mail"></i>
                    <input type="text" placeholder="E-mail">
                </div>
                <div class="input-group">
                    <i data-feather="phone"></i>
                    <input type="text" placeholder="No HP">
                </div>
                <button type="submit" class="btn">Kirim Pesan</button>

            </form>
        </div>
    </section>
    <!--contact section end-->

    <!-- footer-->
    <footer>
        <div class="socials">
            <a href="https://www.instagram.com/ccaaveeraa?igsh=MTVnZzZoeHBjN3luaw==">
                <i data-feather="instagram"></i></a>
            <a href="#">
                <i data-feather="whatsapp"></i></a>
            <a href="#">
                <i data-feather="twitter"></i></a>
            <a href="#">
                <i data-feather="facebook"></i></a>
        </div>

        <div class="links">
            <a href="#home">Home</a>
            <a href="#about">Tentang Kami</a>
            <a href="#menu">Menu</a>
            <a href="#contact">Kontak</a>
        </div>

        <div class="credit">

            <p>Created by <a href="#">Dewi Safira</a> | &copy; 2026.</p>
        </div>
        </div>
    </footer>
    <!-- feather icon-->
    <script>
        feather.replace();
    </script>

    <!--js-->
    <script src=" js/script.js "></script>
</body>

</html>