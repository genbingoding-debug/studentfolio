<?php

include 'config/koneksi.php';

$nama = $_POST['nama'];
$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$role = "user";

$foto = $_FILES['foto']['name'];
$tmp = $_FILES['foto']['tmp_name'];

move_uploaded_file($tmp, "uploads/" . $foto);

$query = mysqli_query($conn, "INSERT INTO users 
(nama, username, password, foto, role)

VALUES

('$nama', '$username', '$password', '$foto', '$role')

");

if($query){
    echo "
    <script>
        alert('Register berhasil!');
        window.location='login.php';
    </script>
    ";
}else{
    echo "
    <script>
        alert('Register gagal!');
        window.location='register.php';
    </script>
    ";
}

?>