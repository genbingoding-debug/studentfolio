// toggle class active
const navbarNav = document.querySelector(".navbar-nav");
const menuToggle = document.querySelector("#menu-toggle");

// klik hamburger
menuToggle.addEventListener("click", function(e) {
    e.preventDefault();
    navbarNav.classList.toggle("active");
});

// klik di luar navbar
document.addEventListener("click", function(e) {
    if (!menuToggle.contains(e.target) && !navbarNav.contains(e.target)) {
        navbarNav.classList.remove("active");
    }
});